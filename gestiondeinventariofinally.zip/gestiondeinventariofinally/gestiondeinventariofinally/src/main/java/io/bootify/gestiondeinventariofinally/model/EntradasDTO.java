package io.bootify.gestiondeinventariofinally.model;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public class EntradasDTO {

    private Long id;

    @NotNull
    private LocalDate fecha;

    @NotNull
    private String descripcion;

    private Long idAdmin;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(final LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(final String descripcion) {
        this.descripcion = descripcion;
    }

    public Long getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(final Long idAdmin) {
        this.idAdmin = idAdmin;
    }

}
