package io.bootify.gestiondeinventariofinally;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestiondeinventariofinallyApplication {

    public static void main(final String[] args) {
        SpringApplication.run(GestiondeinventariofinallyApplication.class, args);
    }

}
