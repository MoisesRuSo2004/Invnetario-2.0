package io.bootify.gestiondeinventariofinally.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


public class AdminDTO {

    private Long id;

    @NotNull
    @Size(max = 255)
    private String usuario;

    @NotNull
    @Size(max = 255)
    private String contrasena;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(final String usuario) {
        this.usuario = usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(final String contrasena) {
        this.contrasena = contrasena;
    }

}
