package io.bootify.gestiondeinventariofinally.controller;

import io.bootify.gestiondeinventariofinally.domain.Insumos;
import io.bootify.gestiondeinventariofinally.domain.Salidas;
import io.bootify.gestiondeinventariofinally.model.DetallesSalidasDTO;
import io.bootify.gestiondeinventariofinally.repos.InsumosRepository;
import io.bootify.gestiondeinventariofinally.repos.SalidasRepository;
import io.bootify.gestiondeinventariofinally.service.DetallesSalidasService;
import io.bootify.gestiondeinventariofinally.util.CustomCollectors;
import io.bootify.gestiondeinventariofinally.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/detallesSalidass")
public class DetallesSalidasController {

    private final DetallesSalidasService detallesSalidasService;
    private final SalidasRepository salidasRepository;
    private final InsumosRepository insumosRepository;

    public DetallesSalidasController(final DetallesSalidasService detallesSalidasService,
            final SalidasRepository salidasRepository, final InsumosRepository insumosRepository) {
        this.detallesSalidasService = detallesSalidasService;
        this.salidasRepository = salidasRepository;
        this.insumosRepository = insumosRepository;
    }

    @ModelAttribute
    public void prepareContext(final Model model) {
        model.addAttribute("idSalidaValues", salidasRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Salidas::getId, Salidas::getId)));
        model.addAttribute("idInsumoValues", insumosRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Insumos::getId, Insumos::getNombre)));
    }

    @GetMapping
    public String list(final Model model) {
        model.addAttribute("detallesSalidases", detallesSalidasService.findAll());
        return "detallesSalidas/list";
    }

    @GetMapping("/add")
    public String add(
            @ModelAttribute("detallesSalidas") final DetallesSalidasDTO detallesSalidasDTO) {
        return "detallesSalidas/add";
    }

    @PostMapping("/add")
    public String add(
            @ModelAttribute("detallesSalidas") @Valid final DetallesSalidasDTO detallesSalidasDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "detallesSalidas/add";
        }
        detallesSalidasService.create(detallesSalidasDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("detallesSalidas.create.success"));
        return "redirect:/detallesSalidass";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id, final Model model) {
        model.addAttribute("detallesSalidas", detallesSalidasService.get(id));
        return "detallesSalidas/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id,
            @ModelAttribute("detallesSalidas") @Valid final DetallesSalidasDTO detallesSalidasDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "detallesSalidas/edit";
        }
        detallesSalidasService.update(id, detallesSalidasDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("detallesSalidas.update.success"));
        return "redirect:/detallesSalidass";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Long id,
            final RedirectAttributes redirectAttributes) {
        detallesSalidasService.delete(id);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("detallesSalidas.delete.success"));
        return "redirect:/detallesSalidass";
    }

}
