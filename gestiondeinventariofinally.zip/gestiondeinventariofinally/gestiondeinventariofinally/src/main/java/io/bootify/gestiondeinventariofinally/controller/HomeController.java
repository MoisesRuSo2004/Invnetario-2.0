package io.bootify.gestiondeinventariofinally.controller;

import io.bootify.gestiondeinventariofinally.service.InsumosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @Autowired
    private InsumosService insumoService;

    @GetMapping("/")
    public String index(Model model) {
        // Obtén el número total de insumos desde el servicio
        int totalInsumos = insumoService.obtenerNumeroDeInsumos();

        // Añade el número de insumos al modelo
        model.addAttribute("totalInsumos", totalInsumos);

        // Redirige a la vista home/index.html
        return "home/index";
    }
}
