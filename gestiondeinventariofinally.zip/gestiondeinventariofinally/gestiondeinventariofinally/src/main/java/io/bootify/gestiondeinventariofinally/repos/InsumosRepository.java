package io.bootify.gestiondeinventariofinally.repos;

import io.bootify.gestiondeinventariofinally.domain.Insumos;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InsumosRepository extends JpaRepository<Insumos, Long> {

    // Método para obtener el último insumo agregado
    Optional<Insumos> findFirstByOrderByIdDesc();
}
