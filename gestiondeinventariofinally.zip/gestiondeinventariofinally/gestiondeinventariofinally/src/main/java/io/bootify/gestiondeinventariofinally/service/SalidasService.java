package io.bootify.gestiondeinventariofinally.service;

import io.bootify.gestiondeinventariofinally.domain.Admin;
import io.bootify.gestiondeinventariofinally.domain.DetallesSalidas;
import io.bootify.gestiondeinventariofinally.domain.Salidas;
import io.bootify.gestiondeinventariofinally.model.SalidasDTO;
import io.bootify.gestiondeinventariofinally.repos.AdminRepository;
import io.bootify.gestiondeinventariofinally.repos.DetallesSalidasRepository;
import io.bootify.gestiondeinventariofinally.repos.SalidasRepository;
import io.bootify.gestiondeinventariofinally.util.NotFoundException;
import io.bootify.gestiondeinventariofinally.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class SalidasService {

    private final SalidasRepository salidasRepository;
    private final AdminRepository adminRepository;
    private final DetallesSalidasRepository detallesSalidasRepository;

    public SalidasService(final SalidasRepository salidasRepository,
            final AdminRepository adminRepository,
            final DetallesSalidasRepository detallesSalidasRepository) {
        this.salidasRepository = salidasRepository;
        this.adminRepository = adminRepository;
        this.detallesSalidasRepository = detallesSalidasRepository;
    }

    public List<SalidasDTO> findAll() {
        final List<Salidas> salidases = salidasRepository.findAll(Sort.by("id"));
        return salidases.stream()
                .map(salidas -> mapToDTO(salidas, new SalidasDTO()))
                .toList();
    }

    public SalidasDTO get(final Long id) {
        return salidasRepository.findById(id)
                .map(salidas -> mapToDTO(salidas, new SalidasDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final SalidasDTO salidasDTO) {
        final Salidas salidas = new Salidas();
        mapToEntity(salidasDTO, salidas);
        return salidasRepository.save(salidas).getId();
    }

    public void update(final Long id, final SalidasDTO salidasDTO) {
        final Salidas salidas = salidasRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(salidasDTO, salidas);
        salidasRepository.save(salidas);
    }

    public void delete(final Long id) {
        salidasRepository.deleteById(id);
    }

    private SalidasDTO mapToDTO(final Salidas salidas, final SalidasDTO salidasDTO) {
        salidasDTO.setId(salidas.getId());
        salidasDTO.setFecha(salidas.getFecha());
        salidasDTO.setCantidad(salidas.getCantidad());
        salidasDTO.setDescripcion(salidas.getDescripcion());
        salidasDTO.setIdAdmin(salidas.getIdAdmin() == null ? null : salidas.getIdAdmin().getId());
        return salidasDTO;
    }

    private Salidas mapToEntity(final SalidasDTO salidasDTO, final Salidas salidas) {
        salidas.setFecha(salidasDTO.getFecha());
        salidas.setCantidad(salidasDTO.getCantidad());
        salidas.setDescripcion(salidasDTO.getDescripcion());
        final Admin idAdmin = salidasDTO.getIdAdmin() == null ? null : adminRepository.findById(salidasDTO.getIdAdmin())
                .orElseThrow(() -> new NotFoundException("idAdmin not found"));
        salidas.setIdAdmin(idAdmin);
        return salidas;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Salidas salidas = salidasRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final DetallesSalidas idSalidaDetallesSalidas = detallesSalidasRepository.findFirstByIdSalida(salidas);
        if (idSalidaDetallesSalidas != null) {
            referencedWarning.setKey("salidas.detallesSalidas.idSalida.referenced");
            referencedWarning.addParam(idSalidaDetallesSalidas.getId());
            return referencedWarning;
        }
        return null;
    }

}
