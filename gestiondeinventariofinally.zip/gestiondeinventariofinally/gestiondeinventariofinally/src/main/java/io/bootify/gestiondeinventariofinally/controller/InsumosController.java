package io.bootify.gestiondeinventariofinally.controller;

import io.bootify.gestiondeinventariofinally.model.InsumosDTO;
import io.bootify.gestiondeinventariofinally.service.InsumosService;
import io.bootify.gestiondeinventariofinally.util.ReferencedWarning;
import io.bootify.gestiondeinventariofinally.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/insumoss")
public class InsumosController {

    private final InsumosService insumosService;

    public InsumosController(final InsumosService insumosService) {
        this.insumosService = insumosService;
    }

    @GetMapping
    public String list(final Model model) {
        model.addAttribute("insumoses", insumosService.findAll());
        return "insumos/list";
    }

    @GetMapping("/add")
    public String add(@ModelAttribute("insumos") final InsumosDTO insumosDTO) {
        return "insumos/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("insumos") @Valid final InsumosDTO insumosDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "insumos/add";
        }
        insumosService.create(insumosDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("insumos.create.success"));
        return "redirect:/insumoss";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id, final Model model) {
        model.addAttribute("insumos", insumosService.get(id));
        return "insumos/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id,
            @ModelAttribute("insumos") @Valid final InsumosDTO insumosDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "insumos/edit";
        }
        insumosService.update(id, insumosDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("insumos.update.success"));
        return "redirect:/insumoss";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Long id,
            final RedirectAttributes redirectAttributes) {
        final ReferencedWarning referencedWarning = insumosService.getReferencedWarning(id);
        if (referencedWarning != null) {
            redirectAttributes.addFlashAttribute(WebUtils.MSG_ERROR,
                    WebUtils.getMessage(referencedWarning.getKey(), referencedWarning.getParams().toArray()));
        } else {
            insumosService.delete(id);
            redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("insumos.delete.success"));
        }
        return "redirect:/insumoss";
    }

}
