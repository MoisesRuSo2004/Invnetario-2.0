package io.bootify.gestiondeinventariofinally.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Min;
import java.util.Objects;

public class InsumosDTO {

    private Long id;

    @NotNull
    @Size(min = 1, max = 255)
    private String nombre;

    @NotNull
    @Min(0) // El stock no puede ser negativo
    private Integer stock;

    // Constructor vacío
    public InsumosDTO() {
    }

    // Constructor con parámetros
    public InsumosDTO(Long id, String nombre, Integer stock) {
        this.id = id;
        this.nombre = nombre;
        this.stock = stock;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(final String nombre) {
        this.nombre = nombre;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(final Integer stock) {
        this.stock = stock;
    }

    // toString
    @Override
    public String toString() {
        return "InsumosDTO{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", stock=" + stock +
                '}';
    }

    // equals y hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        InsumosDTO that = (InsumosDTO) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
