package io.bootify.gestiondeinventariofinally.repos;

import io.bootify.gestiondeinventariofinally.domain.DetallesSalidas;
import io.bootify.gestiondeinventariofinally.domain.Insumos;
import io.bootify.gestiondeinventariofinally.domain.Salidas;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DetallesSalidasRepository extends JpaRepository<DetallesSalidas, Long> {

    DetallesSalidas findFirstByIdSalida(Salidas salidas);

    DetallesSalidas findFirstByIdInsumo(Insumos insumos);

}
