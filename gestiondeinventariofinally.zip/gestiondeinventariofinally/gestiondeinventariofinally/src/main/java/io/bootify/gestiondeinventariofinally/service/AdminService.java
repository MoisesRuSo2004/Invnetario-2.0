package io.bootify.gestiondeinventariofinally.service;

import io.bootify.gestiondeinventariofinally.domain.Admin;
import io.bootify.gestiondeinventariofinally.domain.Entradas;
import io.bootify.gestiondeinventariofinally.domain.Salidas;
import io.bootify.gestiondeinventariofinally.model.AdminDTO;
import io.bootify.gestiondeinventariofinally.repos.AdminRepository;
import io.bootify.gestiondeinventariofinally.repos.EntradasRepository;
import io.bootify.gestiondeinventariofinally.repos.SalidasRepository;
import io.bootify.gestiondeinventariofinally.util.NotFoundException;
import io.bootify.gestiondeinventariofinally.util.ReferencedWarning;
import jakarta.annotation.PostConstruct;

import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AdminService implements UserDetailsService {

    private final AdminRepository adminRepository;
    private final PasswordEncoder passwordEncoder;
    private final EntradasRepository entradasRepository;
    private final SalidasRepository salidasRepository;

    public AdminService(AdminRepository adminRepository,
            PasswordEncoder passwordEncoder,
            final EntradasRepository entradasRepository,
            final SalidasRepository salidasRepository) {
        this.adminRepository = adminRepository;
        this.entradasRepository = entradasRepository;
        this.salidasRepository = salidasRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return adminRepository.findByUsuario(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado: " + username));
    }

    public Admin createAdmin(Admin admin) {
        admin.setContrasena(passwordEncoder.encode((admin.getContrasena())));
        return adminRepository.save(admin);
    }

    @PostConstruct
    public void init() {
        if (adminRepository.count() == 0) {
            Admin admin = new Admin();
            admin.setUsuario("admin");
            admin.setContrasena("123456");
            createAdmin(admin);
        }
    }

    public List<AdminDTO> findAll() {
        final List<Admin> admins = adminRepository.findAll(Sort.by("id"));
        return admins.stream()
                .map(admin -> mapToDTO(admin, new AdminDTO()))
                .toList();
    }

    public AdminDTO get(final Long id) {
        return adminRepository.findById(id)
                .map(admin -> mapToDTO(admin, new AdminDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final AdminDTO adminDTO) {
        final Admin admin = new Admin();
        mapToEntity(adminDTO, admin);
        return adminRepository.save(admin).getId();
    }

    public void update(final Long id, final AdminDTO adminDTO) {
        final Admin admin = adminRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(adminDTO, admin);
        adminRepository.save(admin);
    }

    public void delete(final Long id) {
        adminRepository.deleteById(id);
    }

    private AdminDTO mapToDTO(final Admin admin, final AdminDTO adminDTO) {
        adminDTO.setId(admin.getId());
        adminDTO.setUsuario(admin.getUsuario());
        adminDTO.setContrasena(admin.getContrasena());
        return adminDTO;
    }

    private Admin mapToEntity(final AdminDTO adminDTO, final Admin admin) {
        admin.setUsuario(adminDTO.getUsuario());
        admin.setContrasena(adminDTO.getContrasena());
        return admin;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Admin admin = adminRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Entradas idAdminEntradas = entradasRepository.findFirstByIdAdmin(admin);
        if (idAdminEntradas != null) {
            referencedWarning.setKey("admin.entradas.idAdmin.referenced");
            referencedWarning.addParam(idAdminEntradas.getId());
            return referencedWarning;
        }
        final Salidas idAdminSalidas = salidasRepository.findFirstByIdAdmin(admin);
        if (idAdminSalidas != null) {
            referencedWarning.setKey("admin.salidas.idAdmin.referenced");
            referencedWarning.addParam(idAdminSalidas.getId());
            return referencedWarning;
        }
        return null;
    }

}
