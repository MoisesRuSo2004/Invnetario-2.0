package io.bootify.gestiondeinventariofinally.repos;

import io.bootify.gestiondeinventariofinally.domain.Admin;
import io.bootify.gestiondeinventariofinally.domain.Salidas;
import org.springframework.data.jpa.repository.JpaRepository;


public interface SalidasRepository extends JpaRepository<Salidas, Long> {

    Salidas findFirstByIdAdmin(Admin admin);

}
