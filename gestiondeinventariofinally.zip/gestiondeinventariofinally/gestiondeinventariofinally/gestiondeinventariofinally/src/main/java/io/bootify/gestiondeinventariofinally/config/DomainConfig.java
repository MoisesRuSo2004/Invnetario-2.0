package io.bootify.gestiondeinventariofinally.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Configuration
@EntityScan("io.bootify.gestiondeinventariofinally.domain")
@EnableJpaRepositories("io.bootify.gestiondeinventariofinally.repos")
@EnableTransactionManagement
public class DomainConfig {
}
