package io.bootify.gestiondeinventariofinally.controller;

import io.bootify.gestiondeinventariofinally.domain.Admin;
import io.bootify.gestiondeinventariofinally.model.SalidasDTO;
import io.bootify.gestiondeinventariofinally.repos.AdminRepository;
import io.bootify.gestiondeinventariofinally.service.SalidasService;
import io.bootify.gestiondeinventariofinally.util.CustomCollectors;
import io.bootify.gestiondeinventariofinally.util.ReferencedWarning;
import io.bootify.gestiondeinventariofinally.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/salidass")
public class SalidasController {

    private final SalidasService salidasService;
    private final AdminRepository adminRepository;

    public SalidasController(final SalidasService salidasService,
            final AdminRepository adminRepository) {
        this.salidasService = salidasService;
        this.adminRepository = adminRepository;
    }

    @ModelAttribute
    public void prepareContext(final Model model) {
        model.addAttribute("idAdminValues", adminRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Admin::getId, Admin::getUsuario)));
    }

    @GetMapping
    public String list(final Model model) {
        model.addAttribute("salidases", salidasService.findAll());
        return "salidas/list";
    }

    @GetMapping("/add")
    public String add(@ModelAttribute("salidas") final SalidasDTO salidasDTO) {
        return "salidas/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("salidas") @Valid final SalidasDTO salidasDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "salidas/add";
        }
        salidasService.create(salidasDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("salidas.create.success"));
        return "redirect:/detallesSalidass/add?entradaId=" + salidasDTO.getId();
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id, final Model model) {
        model.addAttribute("salidas", salidasService.get(id));
        return "salidas/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Long id,
            @ModelAttribute("salidas") @Valid final SalidasDTO salidasDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "salidas/edit";
        }
        salidasService.update(id, salidasDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("salidas.update.success"));
        return "redirect:/salidass";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Long id,
            final RedirectAttributes redirectAttributes) {
        final ReferencedWarning referencedWarning = salidasService.getReferencedWarning(id);
        if (referencedWarning != null) {
            redirectAttributes.addFlashAttribute(WebUtils.MSG_ERROR,
                    WebUtils.getMessage(referencedWarning.getKey(), referencedWarning.getParams().toArray()));
        } else {
            salidasService.delete(id);
            redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("salidas.delete.success"));
        }
        return "redirect:/salidass";
    }

}
