package io.bootify.gestiondeinventariofinally.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


public class DetallesEntradasDTO {

    private Long id;

    @NotNull
    @Size(max = 255)
    private String nombre;

    @NotNull
    private Integer cantidad;

    private Long idEntrada;

    private Long idInsumo;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(final String nombre) {
        this.nombre = nombre;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(final Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Long getIdEntrada() {
        return idEntrada;
    }

    public void setIdEntrada(final Long idEntrada) {
        this.idEntrada = idEntrada;
    }

    public Long getIdInsumo() {
        return idInsumo;
    }

    public void setIdInsumo(final Long idInsumo) {
        this.idInsumo = idInsumo;
    }

}
